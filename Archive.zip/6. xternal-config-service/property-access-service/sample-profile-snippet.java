import org.springframework.jndi.JndiObjectFactoryBean;

public class DBConfig {


    @Bean
    @Profile("dev")
    public DataSource defaultDB() {
        return new EmbeddedDatabaseBuilder()
        .setType(EmbeddedDatabaseType.H2)
        .addScript("classpath:schema.sql")
        .build();
    }

    @Bean
    @Profile("prod")
    public DataSource jndiDataSource() {

        JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
        //all props can be declared
        return (DataSource) jndiObjectFactoryBean.getObject();
    }

    @Bean
    @Profile("qa")
    public DataSource qaDataSource() {

        JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
        //all props can be declared
        return (DataSource) jndiObjectFactoryBean.getObject();
    }

}
